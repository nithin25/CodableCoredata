//
//  PersonViewControllerTableDatasource.swift
//  CodableCoredata
//
//  Created by Nithin Kumar on 03/04/2020.
//  Copyright © 2020 Nithin Kumar. All rights reserved.
//

import UIKit

class PersonViewControllerTableDatasource: NSObject, UITableViewDataSource {
    let personListViewModel: PersonListViewModel
    
    init(_ personListViewModel: PersonListViewModel) {
        self.personListViewModel = personListViewModel
    }
    
    // MARK: - Table view data source

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.personListViewModel.numberOfPersons()
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PersonCell", for: indexPath) as! PersonCell

        let personViewModel = self.personListViewModel.person(atIndex: indexPath.row)
        cell.configure(personViewModel)

        return cell
    }
}
