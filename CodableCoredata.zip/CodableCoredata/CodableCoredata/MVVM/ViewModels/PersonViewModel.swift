//
//  PersonViewModel.swift
//  CodableCoredata
//
//  Created by Nithin Kumar on 01/04/2020.
//  Copyright © 2020 Nithin Kumar. All rights reserved.
//

import UIKit

class PersonViewModel: NSObject {
    private var person: Person
    init(_ person: Person) {
        self.person = person
    }
    
    var id: String {
        get {
            return self.person.id
        }
    }
    
    var name: String {
        get {
            return self.person.name
        }
    }
    
    var city: String {
        get {
            return self.person.city
        }
    }
    
    var state: String {
        get {
            return self.person.state
        }
    }
    
    var country: String {
        get {
            return self.person.country
        }
    }
}
