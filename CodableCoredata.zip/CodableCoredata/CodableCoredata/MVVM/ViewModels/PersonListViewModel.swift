//
//  PersonListViewModel.swift
//  CodableCoredata
//
//  Created by Nithin Kumar on 01/04/2020.
//  Copyright © 2020 Nithin Kumar. All rights reserved.
//

import UIKit

protocol PersonListViewModelDelegate: NSObject {
    func parsePersonsSuccess()
    func parsePersonsFailedWithMessage(_ message: String)
}

class PersonListViewModel: NSObject {
    
    private var persons: Array<Person> {
        didSet {
            self.delegate?.parsePersonsSuccess()
        }
    }
    
    weak var delegate: PersonListViewModelDelegate?
    
    init(_ delegate: PersonListViewModelDelegate?) {
        self.delegate = delegate
        self.persons = Array<Person>()
    }
    
     let contentJson = """
                        [
                           {
                              "id":"1",
                              "name":"Ganeshji",
                              "address":{
                                 "city":"Bangalore",
                                 "state":"Karnataka",
                                 "country":"India"
                              }
                           },
                           {
                              "id":"2",
                              "name":"Nithin Shriyan",
                              "address":{
                                 "city":"Udupi",
                                 "state":"Karnataka",
                                 "country":"India"
                              }
                           },
                           {
                              "id":"3",
                              "name":"Pooja",
                              "address":{
                                 "city":"Srinagar",
                                 "state":"Uttarakhand",
                                 "country":"India"
                              }
                           },
                           {
                              "id":"4",
                              "name":"Maccha",
                              "address":{
                                 "city":"Manasa",
                                 "state":"Madhya pradesh",
                                 "country":"India"
                              }
                           },
                           {
                              "id":"5",
                              "name":"Pedda",
                              "address":{
                                 "city":"Pedda City",
                                 "state":"IpTeLLddya",
                                 "country":"IpTeLLddyadesha"
                              }
                           },
                           {
                              "id":"6",
                              "name":"person 1",
                              "address":{
                                 "city":"Bangalore1",
                                 "state":"Karnataka1",
                                 "country":"India1"
                              }
                           },
                           {
                              "id":"7",
                              "name":"person 2",
                              "address":{
                                 "city":"Bangalore2",
                                 "state":"Karnataka2",
                                 "country":"India2"
                              }
                           },
                           {
                              "id":"8",
                              "name":"sejal",
                              "address":{
                                 "city":"Mumbai",
                                 "state":"Maharashtra",
                                 "country":"India"
                              }
                           },
                           {
                              "id":"8",
                              "name":"persona",
                              "address":{
                                 "city":"Mangalore",
                                 "state":"Karnataka",
                                 "country":"India"
                              }
                           },
                           {
                              "id":"9",
                              "name":"Coroooonaaaaa",
                              "address":{
                                 "city":"han",
                                 "state":"Visrus city",
                                 "country":"Cheeeeeeee"
                              }
                           },
                           {
                              "id":"10",
                              "name":"gajal majal",
                              "address":{
                                 "city":"Bangalore",
                                 "state":"Karnataka",
                                 "country":"India"
                              }
                           }
                        ]
                       """
    
    
    
    func parsePersonJson() {
        let responseData = Data(contentJson.utf8)
        
        let decoder = JSONDecoder()
        let managedObjectContext = CoreDataStorage.shared.managedObjectContext()
        guard let codingUserInfoKeyManagedObjectContext = CodingUserInfoKey.managedObjectContext else {
            fatalError("Failed to retrieve managed object context Key")
        }
        decoder.userInfo[codingUserInfoKeyManagedObjectContext] = managedObjectContext
        
        do {
            let result = try decoder.decode([Person].self, from: responseData)
            self.persons = result
            print(result)
        } catch let error {
            print("decoding error: \(error)")
            self.delegate?.parsePersonsFailedWithMessage("Your error message!")
        }
        
        CoreDataStorage.shared.clearStorage(forEntity: "Person")
        CoreDataStorage.shared.saveContext()
        
        let paths = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true)
        print("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@")
        print(paths[0])
        
        if self.persons.count > 0 {
            let encoder = JSONEncoder()
            do {
                let encodedData = try encoder.encode(self.persons)
                print("Endoded data prints below")
                if let encodedString = String(data: encodedData, encoding: .utf8) {
                    print(encodedString)
                }
            } catch let err {
                print("encoding error \(err)")
            }
        }
    }
    
    func numberOfPersons() -> Int {
        return self.persons.count
    }
    
    func person(atIndex index: Int) -> PersonViewModel {
        return PersonViewModel(self.persons[index])
    }
}
