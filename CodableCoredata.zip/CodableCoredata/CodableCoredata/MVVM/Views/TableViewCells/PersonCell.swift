//
//  PersonCell.swift
//  CodableCoredata
//
//  Created by Nithin Kumar on 01/04/2020.
//  Copyright © 2020 Nithin Kumar. All rights reserved.
//

import UIKit

class PersonCell: UITableViewCell {
    @IBOutlet weak var idLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var stateLabel: UILabel!
    @IBOutlet weak var countryLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func configure(_ personViewModel: PersonViewModel) {
        self.idLabel.text = personViewModel.id
        self.nameLabel.text = personViewModel.name
        self.cityLabel.text = personViewModel.city
        self.stateLabel.text = personViewModel.state
        self.countryLabel.text = personViewModel.country
    }
}
