//
//  Person.swift
//  CodableCoredata
//
//  Created by Nithin Kumar on 01/04/2020.
//  Copyright © 2020 Nithin Kumar. All rights reserved.
//

import UIKit
import CoreData

class Person: NSManagedObject, Codable {
    @NSManaged var id: String
    @NSManaged var name: String
    @NSManaged var city:String
    @NSManaged var state: String
    @NSManaged var country: String
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case city
        case state
        case country
        case address
    }
    
    required convenience init(from decoder: Decoder) throws {
        guard let codingUserInfoKeyManagedObjectContext = CodingUserInfoKey.managedObjectContext,
            let managedObjectContext = decoder.userInfo[codingUserInfoKeyManagedObjectContext] as? NSManagedObjectContext,
            let entity = NSEntityDescription.entity(forEntityName: "Person", in: managedObjectContext) else {
            fatalError("Failed to decode User")
        }

        self.init(entity: entity, insertInto: managedObjectContext)

        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(String.self, forKey: .id)
        name = try container.decode(String.self, forKey: .name)
        
        let address = try container.nestedContainer(keyedBy: CodingKeys.self, forKey: .address)
        city = try address.decode(String.self, forKey: .city)
        state = try address.decode(String.self, forKey: .state)
        country = try address.decode(String.self, forKey: .country)
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(id, forKey: .id)
        try container.encode(name, forKey: .name)
        
        var address = container.nestedContainer(keyedBy: CodingKeys.self, forKey: .address)
        try address.encode(city, forKey: .city)
        try address.encode(state, forKey: .state)
        try address.encode(country, forKey: .country)
    }
}
