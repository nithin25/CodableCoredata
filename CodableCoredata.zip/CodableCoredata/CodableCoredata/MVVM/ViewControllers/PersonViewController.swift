//
//  PersonViewController.swift
//  CodableCoredata
//
//  Created by Nithin Kumar on 01/04/2020.
//  Copyright © 2020 Nithin Kumar. All rights reserved.
//

import UIKit

class PersonViewController: UITableViewController {
    var personListViewModel: PersonListViewModel!
    var tableViewDatasource: PersonViewControllerTableDatasource!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.estimatedRowHeight = 150
        self.tableView.rowHeight = UITableView.automaticDimension

        self.title = "Persons"
        self.personListViewModel = PersonListViewModel(self)
        self.tableViewDatasource = PersonViewControllerTableDatasource(self.personListViewModel)
        self.tableView.dataSource = self.tableViewDatasource
        
        self.personListViewModel.parsePersonJson()
    }
}

extension PersonViewController: PersonListViewModelDelegate {
    func parsePersonsSuccess() {
        self.tableView.reloadData()
    }
    
    func parsePersonsFailedWithMessage(_ message: String) {
        self.showError(nil, message: message)
    }
}
